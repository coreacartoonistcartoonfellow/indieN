(function($){
	$(".type-ionicons").click(function(){
		window.ion_picker = "#" + $(this).prop("id");
		tb_show("Ionic Icons", "#TB_inline?width=600&height=490&inlineId=ionicons");
		$("#TB_ajaxContent").attr("style","height:490px;");
	});
	$(".type-images").click(function(){
		window.images_picker = "#" + $(this).prop("id");
		if(app_images) {
			app_images.open();
			return;
		}
		var app_images = wp.media({
				title: "Select or Upload Media Of Your Chosen Persuasion",
				button: {
					text: "Use this media"
				},
				multiple: false
		});
		app_images.on("select",function(){
			var attachment = app_images.state().get("selection").first().toJSON();
			var url = attachment.url ;
		$(window.images_picker).val(url);
		});
		app_images.open();
		return false;
	});
	$(".app_wp_page_ionicons").click(function(){
		var ion_class = $(this).find(".ion").attr("class");
		$(window.ion_picker).val(ion_class);
		tb_remove();
	});
})(jQuery);
